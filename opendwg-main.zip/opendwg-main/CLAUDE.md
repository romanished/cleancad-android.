# CleanCAD Viewer

Ad-free Android DWG viewer for construction-site users. Open source, GPL v3.
(GitHub repo name is `opendwg`; the app's display name is "CleanCAD Viewer".)

## Stack
- Kotlin, Android Views (XML layouts). minSdk 24, compile/targetSdk 36.
- DWG parsing: **LibreDWG 0.13.4** (GPL v3), vendored as a git submodule under
  `app/src/main/cpp/libredwg`, built via CMake/NDK, called over JNI.
- Rendering pipeline: **DWG → native serializer (Dwg_Data 직접 순회) → binary buffer
  → Kotlin NativeDecoder → Drawing model → custom `Canvas` (`DrawingView`)**.
  DXF 텍스트 중간단계는 Phase 8에서 제거됨. Task 11(2026-05-29)에서
  `nativeDwgToDxf` 함수 및 DxfParser/Reader/CharsetDetector 코드 완전 삭제 완료.
- Package / applicationId: `io.github.june690602_blip.cleancad`

## Key docs (read these first to get oriented)
- Design spec — all decisions: `docs/superpowers/specs/2026-05-25-cleancad-viewer-design.md`
- Phase 8 plan (현재 진행 중): `docs/superpowers/plans/2026-05-27-phase8-libredwg-native.md`
- Phase 7 plan (DXF 시도, 부분 성공): `docs/superpowers/plans/2026-05-27-phase7-rendering-quality.md`

## Status (2026-06-10) — 이슈2 · 최근파일 재열기 · 첫화면 인셋 머지 완료

**이슈2 · 최근파일 재열기 · 첫화면 인셋까지 main 에 머지 완료.** 모두 실폰(S21+) 사용자
확인 완료 — 최근파일 재열기 "잘된다", 첫화면 인셋 캡처 확인 (2026-06-10).

> **최근파일 재열기 (2026-06-10) 완료·머지 — 카톡 URI 재열기 권한 문제 해결.**
> 근본 원인: 카톡·공유 `content://` URI 는 `takePersistableUriPermission` 불가 → 앱 재시작
> 후 재열기가 권한 오류로 실패. 수정(복사본 우선): 로드 성공 시 `cacheDir` 복사본을
> `filesDir/recent/<hash>.dwg` 로 이동해 영구 보관, 재열기는 이 복사본을 정본으로 직접 파싱
> (원본 URI 권한 불필요), 복사본 소실 시에만 원본 URI 폴백 → 그것도 실패하면 목록 자동 제거.
> 보관 10개+200MB 캡(`RetentionPolicy` 순수함수), 길게눌러 삭제, 고아 sweep. 검증: 단위테스트
> 82개 통과(기존 77+RetentionPolicy 5), `assembleDebug` 성공, 실폰 확인 "잘된다". 상세:
> `docs/superpowers/handoff/2026-06-10-recent-files-reopen-done.md`.
>
> **첫 화면 상태바 인셋 (2026-06-10) — edge-to-edge 겹침 수정.** targetSdk 36에서 안드15+
> edge-to-edge 강제로 툴바(앱 이름)가 상태바와 겹쳐 구분이 안 됐다. `activity_main.xml` 루트에
> `android:fitsSystemWindows="true"` 적용 → 상태바 높이만큼 패딩, 툴바가 정상 위치로 내려감.
> 실폰(S21+) 캡처로 before/after 확인.

> **이슈2 (2026-06-10) XCLIP 부분침범 해치 기하 클리핑 완료 — 표제란 회색 덩어리 해결.**
> 근본 원인: 배치도 맵(XCLIP된 INSERT)의 도로 솔리드 해치(216K 폭)가 클립창을 22.3K
> 침범하는데, HATCH 클립 처리가 완전밖/극단초과만 통째 컬링하고 **부분 침범은 무클립
> 통과** → 채움이 클립창 오른쪽(=표제란) 위로 번짐. 수정: `write_hatch`가 루프 빌드 직후
> 루프별 **Sutherland–Hodgman 클립**(`clip_loop_to_rect`, 클립창 완전포함 루프는 무변경
> 빠른경로) — 채움/패턴/경계 stroke 모두 클립 안으로. overflow 통째 컬링은 제거(클리핑이
> 대체). 검증: H bbox 216000×18875→180000×16835(클립창 정확 일치), 엔티티 101,603 불변,
> ref.dwg 192,958(+76 — 통째컬링되던 해치 복귀, 회색띠 재발 없음), 단위테스트 77개.
> ⚠️ 전 세션의 "도면↔원점 걸침 stray" 가설은 실측 기각(그런 엔티티 0건). 진단 핵심:
> 사용자 스크린샷의 `223-5 도` 라벨로 화면↔월드 캘리브레이션 + native 임시 DLOG.
> 상세: `docs/superpowers/handoff/2026-06-10-issue2-xclip-hatch-clipping.md`.
>
> **Phase 8.6 (2026-06-09) HATCH 패턴 렌더링 완료 — 실제 패턴 라인 재현.**
> 근본 원인: 비솔리드 HATCH가 경계선만 렌더(패턴 정의선 무시) → 다른 캐드앱 대비 시각 차이 큼.
> 수정: `dwg_serialize.c` `write_hatch` 재작성 — 로드 시 1회 패턴 def-line을 경계로 **스캔라인
> 클리핑**(even-odd, dash)해 라인 세그먼트로 확장(u축=방향/v축=수직 좌표계로 평행선=수평선 단순화).
> 경계는 라인/폴리라인+bulge/원호 테셀레이션(타원호·스플라인은 chord+솔리드 폴백). 밀도 캡
> (4000 seg/hatch)+렌더러 줌 게이트(`screenSpacing<3px`면 반투명 솔리드)로 Phase 10 성능 유지.
> protocol v2: `patternFallback`/`minLineSpacing`/`fillLines` 추가. **검증(ref.dwg, 에뮬 API36):**
> 로드 성공 192,882 엔티티(hatch 160), 수치 캘리브레이션 — ANSI31(솔리드)·AR-RROOF(점선) 정상
> 생성, 폴백 0, def-line=모델공간 해상형태 직접 사용 확인. 단위테스트 77개. 상세:
> `docs/superpowers/handoff/2026-06-09-phase8.6-hatch-pattern.md`.
>
> **Phase 8.6 후속 버그수정 (PR 검증 중, 사용자 파일 `01.건축도면-1.dwg` 실측) — 곡선 경계 2건:**
> ① **CW(`is_ccw=0`) 경계 CIRCULAR_ARC 각도가 Y-mirror 저장** → raw 각도로 emit_arc 하면 reflex
> sweep(~2π)=반지름 도면급 **거대 원** → SOLID 해치가 화면 덮는 '쪼개진 회색 원'으로 보임.
> `build_one_loop`에서 `!is_ccw`면 각도 negate (검증: hatch bbox 316845×340993→216000×18875).
> ② **타원/스플라인(ct3/4) endpoint 가 (0,0) 미설정** 시 chord 폴백이 원점까지 늘어나 bbox
> 폭주(ANSI37 폭 1,237만) → 퇴화(≈0,0) endpoint skip. (`825b95d`)
> ⚠️ **교훈: 디바이스 진단은 반드시 "사용자가 보는 그 파일"로.** 이번에 처음 `ref.dwg`(엉뚱한
> 파일)로 진단해 한참 헛수고 → 폰 `logcat`(`CleanCAD/ViewModel load:`)으로 실파일 확인 후 해결.
> 줌게이트 회색채움은 한때 제거했다가(오진단 기반) **revert**(`ca4e466`) — 원래 동작 복원.
>
> **Phase 10 (2026-05-30) 렌더링 성능 최적화 완료 — 팬/줌 렉 제거.**
> 근본 원인: `EntityRenderer.drawAll`이 매 프레임 188K 엔티티 전체를 2회 스캔 + `worldBounds()`
> 매 프레임 재계산(polyline/hatch `minOf` 람다 → iterator/박싱 할당 → GC 폭증). 공간 인덱스 없음.
> 수정: **`render/SpatialIndex.kt`** 신규 — 로드 시 1회 ① 엔티티별 bounds 캐시 + ② 균일 그리드
> (긴 축 128분할) 구축. `drawAll`은 viewport와 겹치는 셀의 후보만 조회(187K→가시영역 수~수천),
> 캐시 bounds로 컬링. 텍스트도 인덱싱(넉넉한 근사 bounds)해 viewport 컬링 추가.
> **측정(`04_chamgo.dwg` 187,907 엔티티, 에뮬 gfxinfo): fit 팬 1600ms→97~150ms(~10–16×),
> 중간 줌(9x) 18ms, 고배율(81x) 17ms — 작업 줌은 모두 ~60fps.** 단위테스트 SpatialIndex 6개 추가.
> 시각 검증: 줌인 시 한글/치수/표제란 텍스트 정상(누락 없음). 비트맵 캐시(#3)는 fit 팬이라는
> 드문 케이스만 남아 **불필요 판단**(회귀 위험·메모리 대비 효용 낮음).
> 상세: `docs/superpowers/handoff/2026-05-30-phase10-render-performance.md` (완료 노트 추가됨).
>
> **Phase 9.4 (2026-05-30) XCLIP 완료 — 떡덩어리/겹침 해결, 사용자 만족.**
> 근본 원인: XCLIP(SPATIAL_FILTER) 미지원 — crop/xref 블록이 클립 무시하고 블록 전체를 렌더해 겹침.
> 수정: `dwg_serialize.c`가 INSERT의 SPATIAL_FILTER(xdic→ACAD_FILTER→SPATIAL)로 자식 엔티티를
> **기하 클리핑**(선/폴리라인 Liang-Barsky 분할, 해치 overflow 컬링, 중첩 crop 클립 교집합).
> 좌표 모델 실측 확정(`clip_world = childTransform(invXform2D(clip_vert))`). seg_clipped=5,115,
> emitted 435,609→187,907. **시트 탭 제거**(무의미 판단, SheetClusterer는 displayExtents용 내부 유지),
> displayExtents=시트합집합, INSERT base_pt 보정 포함. **모두 working tree 미커밋.**
> ⚠️ 에뮬레이터 함정: `adb install -r`이 native .so 갱신 안 함 → native 변경 시 uninstall+install 필수.
>
> **다음(Phase 10): 렌더링 성능 최적화** — 팬/줌 렉. 근본원인=매 프레임 188K 엔티티 전체 순회+
> worldBounds 재계산, 공간 인덱스/캐싱 없음. plan: worldBounds 캐싱 → 공간 그리드 인덱스 → 비트맵 캐시.
> 상세는 Phase 10 핸드오프 참조.

### 작동 중 ✅
- **최근파일 재열기 (2026-06-10, 복사본 우선)** — 로드 성공 시 복사본을 `filesDir/recent/<hash>.dwg`
  에 영구 보관, 재열기는 이 복사본을 정본으로 직접 파싱(원본 URI 권한 불필요). 복사본 소실 시에만
  원본 URI 폴백 → 실패 시 목록 자동 제거. 10개+200MB 캡(`RetentionPolicy`), 길게눌러 삭제, 고아 sweep.
  카톡 비-persistable URI 재시작 후 재열기 실패가 해소됨. 실폰(S21+) 확인 "잘된다". 단위테스트 82개.
- **첫 화면 상태바 인셋 (2026-06-10)** — targetSdk 36 edge-to-edge 강제로 툴바(앱 이름)가 상태바와
  겹치던 문제. `activity_main.xml` 루트에 `fitsSystemWindows="true"` 적용. 실폰 캡처 확인.
- **XCLIP 부분침범 해치 클리핑 (이슈2)** — 클립창을 부분 침범하는 자식 HATCH의 경계 루프를
  Sutherland–Hodgman으로 클립창에 클립(`clip_loop_to_rect`). 채움/패턴/경계가 표제란 등
  클립 밖으로 안 번짐. overflow 통째 컬링 제거 — 클립 안 부분은 정상 표시.
  실폰(S21+) 사용자 확인 완료 (2026-06-10).
- **HATCH 패턴 채움 (Phase 8.6)** — 비솔리드 HATCH를 임베드 def-line으로 실제 패턴 라인 렌더
  (ANSI31·AR-RROOF 등). native `write_hatch`가 스캔라인 클리핑(even-odd+dash)으로 채움 라인 생성,
  줌 게이트로 멀리=반투명 솔리드/가까이=패턴 라인. 곡선 경계·밀도초과는 솔리드 폴백. (브랜치 미머지)
- **파일 연결(열기) — 카톡 등에서 .dwg "열기" 시 앱 실행 (Phase 11)** — AndroidManifest VIEW 필터를
  표준 DWG MIME(application/acad·x-dwg·dwg, image/vnd.dwg·x-dwg, drawing/dwg, application/x-autocad)
  + `application/octet-stream`(카톡은 .dwg 를 일반 바이너리로 넘김)로 확장. octet-stream 을 폭넓게
  받는 부작용은 `DrawingViewModel.isLikelyDwg`(파일명 .dwg / 매직헤더 "AC1x"·"AC2x")로 파싱 전 차단,
  아니면 안내 후 에러화면. 검증: `cmd package query-activities` 로 octet-stream/image/vnd.dwg VIEW
  모두 ViewerActivity 해석 확인, octet-stream+실파일 → 렌더 성공, isLikelyDwg 단위테스트 9개.
  S21+(안드14~15) 카톡 "열기" → image/vnd.dwg 로 시스템 선택창 동작 확인.
- **공유(SEND) 받기 + 안드16 카톡 한계 (Phase 11.2)** — S25+(안드16)에선 카톡 미리보기 "열기"가
  인텐트를 쏘기 전에 자체 queryIntentActivities 로 핸들러를 찾는데, 안드 11+ 패키지 가시성 때문에
  우리 앱을 못 봐서 "앱 없음"으로 끝남(로그상 START/VIEW 인텐트 자체가 없음 → 우리 필터 도달 못 함,
  카톡측 한계라 우리가 못 고침). 우회: ViewerActivity 에 **ACTION_SEND 필터 + EXTRA_STREAM 처리**
  (`incomingUri()`, `IntentCompat.getParcelableExtra`) 추가 → 시스템 공유시트(가시성 무관)로
  "공유 → CleanCAD" 경로 확보. 검증: SEND 필터 query-activities 해석 + EXTRA_STREAM URI 로드 SUCCESS.
  시스템 경로(내 파일→열기)는 S25+ 에서 정상 동작 확인.
- **TEXT/MTEXT 정렬 지원 — 디멘션 숫자 우측 치우침 수정 (Phase 11.3)** — 기존엔 모든 텍스트를
  insertion point 기준 좌측정렬로 그려, 가운데정렬(attachment=5)인 디멘션 측정값이 우측으로 치우쳤다.
  native 가 TEXT(`horiz/vert_alignment`+정렬 시 `alignment_pt`)·MTEXT(`attachment` 1-9)를 halign/valign
  두 int 로 내보내고(프로토콜에 8바이트 추가 — TEXT/MTEXT/ATTRIB/MLEADER 4개 emitter 전부 동기화),
  디코더·모델(DxfText/DxfMText `hAlign`/`vAlign`)·렌더러(`Paint.Align` + fontMetrics 수직 오프셋)가
  반영. ATTRIB/MLEADER 는 0,0(좌측+베이스라인)로 기존 동작 유지. 검증: 단위테스트 75개(정렬 2개 추가),
  파싱 무결성(엔티티 192,882 동일=프로토콜 동기 확인), 실폰(S21+) 디멘션 숫자 가운데 정렬 사용자 확인.
- **Play Store 출시 준비 (Phase 11.1)** — 릴리즈 R8 minify+resource shrink 켬(`proguard-rules.pro`에
  JNI/NativeDwg keep), 전용 블루프린트 아이콘(적응형 벡터 + 5밀도 webp + `docs/store/icon-512.png`),
  `docs/privacy.html`(수집0), `docs/store/listing.md`(KR/EN), 스크린샷 3장. 검증: R8 릴리즈 실기
  렌더 정상·단위테스트 73개·`.so` 16KB LOAD 정렬·`bundleRelease` AAB(3 ABI+심볼) 생성. 사용자 액션
  (키스토어·AAB 빌드·콘솔 업로드)은 `docs/store/RELEASE-GUIDE.md`. ⚠️ 키스토어는 본인 생성(gitignore됨).
- LibreDWG 바이너리 API로 직접 DWG 파싱 (DXF 중간단계 없음)
- **줌아웃 시 글자 힌트 막대 (Phase 11.5)** — 글자높이 화면 10px 미만이면 글리프를 안 그려서(ANR 방지)
  멀리서 글자 존재를 인지 못 했다. 이제 3~10px 구간은 텍스트 진행방향으로 **힌트 막대(faint 선)**를
  batch(`hintBatch`)로 1회 drawLines. <3px 는 노이즈라 스킵. ZWCAD 처럼 "여기 글자 있음" 인지 가능.
- 한글/일본어/중국어 인코딩 정상 — **버전별 분기**(Phase 11.4): R2007+(AC1021+)는 텍스트가
  UTF-16(TU)라 `bit_convert_TU`, ~R2004는 코드페이지(CP949 등)라 `bit_TV_to_utf8(codepage)`.
  이전엔 모든 버전에 `bit_TV_to_utf8`를 써서 AC1032 등 신버전 한글이 깨졌다(`tv_to_utf8`에서 분기).
  검증: 01_arch.dwg(AC1032) 로드 시 "900이상·마감두께·90°" 등 정상 디코드(이전 "$좔·젎碼X" 깨짐).
- 엔티티별 색상 (BYLAYER/BYBLOCK/ACI/RGB)
- 13MB DWG 파일 1초 내 파싱 (110K objects → 100K entities)
- 단위 테스트 73개 통과 (NativeDecoder 19 + ColorInvert 13 + AciColor 10 + DwgValidation 9 +
  SheetClusterer 6 + CoordTransform 6 + SpatialIndex 6 + EntityColorDecoding 3 + ExampleUnit 1)
- LINE/CIRCLE/ARC/POLYLINE/3DFACE/SOLID/ELLIPSE/SPLINE/HATCH/DIMENSION/LEADER/TEXT/MTEXT 디코딩
- **MULTILEADER(MLEADER) 지원 (Phase 10.1)** — 리더선→LWPOLYLINE, dogleg→LINE, content→MTEXT로
  분해해 native에서 내보냄(디코더 변경 없음). `04_참고도면.dwg` 239개 MLEADER 주석 렌더 확인.
- **POINT 지원 (Phase 10.2)** — 새 DWGB_TYPE_POINT(17). `DxfPoint` 모델, 줌 무관 1.5px 고정 점으로
  렌더(픽셀컬 예외). 클러스터링 제외(centroid=null)·extents 미반영(worldBounds=null), 공간인덱스엔
  포함. `04_참고도면.dwg` 2,763점 렌더(나머지는 XCLIP 클립 밖이라 컬링).
- **IMAGE/OLE2FRAME/MINSERT/ATTRIB 지원 (Phase 10.3)** — 모두 native에서 기존 레코드로 분해
  (디코더/모델/렌더 무변경): IMAGE=pt0+uvec·vvec 4코너 프레임→LWPOLYLINE, OLE2FRAME=pt1/pt2
  사각형, MINSERT=블록을 num_cols×num_rows 격자 전개, ATTRIB=INSERT 속성값→TEXT(부모 변환 적용).
  검증: "입면도"·"1:60"·"DRAWING NAME" 표제란 라벨(ATTRIB), 사진 프레임(IMAGE) 렌더 확인.
  ⚠️ ATTDEF(블록 내 속성 정의 템플릿)는 의도적 미렌더(ATTRIB 값으로 대체).
- **WIPEOUT 프레임 미렌더 (Phase 10.5)** — Phase 10.3에서 WIPEOUT을 IMAGE와 같은 프레임으로 내보냈으나,
  실측 결과 `pt0+uvec*image_size+vvec*image_size`는 클립 폴리곤을 감싸는 "이미지 정사각형"(w==h)이라
  실제 마스크보다 훨씬 크다(`04` 최대 574,790×574,790, 시트 폭 ~430K를 뚫고 나감). AutoCAD/ZWCAD도
  기본값(WIPEOUTVARIABLES.display_frame=0)에서 테두리 미표시. 마스킹 자체를 구현 안 하므로
  WIPEOUT은 **완전 skip**(dispatch+entity_local_repr 제거). 엔티티 192,897→192,882(WIPEOUT 15개).
- **도면목록표/표지/사업개요 컬링 해결 (Phase 10.4)** — 원인: SheetClusterer가 P5-P95로 시트 bbox를
  클리핑해, 엔티티 적고 메인 위에 떨어진 저밀도 시트(표지·도면목록표·사업개요·위치도)가 상위 5%로
  밀려 검출 bbox에서 빠짐 → 그 합집합 displayExtents가 renderBounds로 그 시트들을 컬링. 수정:
  `SheetClusterer.inclusiveExtents` — 검출 시트 합집합을 seed로 1배 확장한 영역 안의 엔티티 bbox.
  인접 저밀도 시트는 포함, 먼 junk outlier(±수백만)는 제외. 도면목록표 표/사업개요/위치도 렌더 확인.
- INSERT 블록 재귀 전개 (depth 5, affine transform)
- **DIMENSION anonymous block 전개 (Phase 8.5)** — `clone_ins_pt` 변환으로 화살표/연장선/측정값
  텍스트가 제 위치에 렌더. 사용자 확인됨 ("수치들은 다 제자리로 가있네").
- model-space만 순회 (paper-space 무시 — 검증: PSPACE num_owned=0, layout block 모두 비어 있음)
- Layer name → index 캐시 (O(N²) → O(N))
- 화면상 1px 미만 엔티티 + 4px 미만 텍스트 컬링 → 100K 엔티티에서도 ANR 안 남
- HATCH 솔리드 채우기 25% 반투명 + 경계 항상 stroke (검정 덩어리 방지)
- `fit-to-screen`이 `extents`/`displayExtents` 둘 다 null 처리 — Kotlin에서 entity bounds로 계산
- **시트 클러스터링 + TabLayout (Phase 8.7)** — P5-P95 percentile 기반 그리드 BFS 클러스터링.
  ref.dwg 기준 9개 시트 자동 감지 (171ms), 탭별 fit-to-screen 동작. 디바이스 검증 완료 (2026-05-28).
  SheetClusterer: `model/SheetClusterer.kt`, UI: `ui/ViewerActivity.kt` + `render/DrawingView.kt`

### 진행 중 ⏳ — 다음 세션에서 이어갈 작업

다음 세션 작업 (우선순위 순):
1. **세로 흰 선** — 사용자가 이슈2 타깃에서 제외했지만 미조사 잔존 (ref.dwg 우상단
   빨간 사선과 동류 가능성).
2. **"ㄱ 모양" 산발 마커 미조사 (Task 12)** — 시트 8/9 보고. LEADER arrowhead/DIMENSION 정의점/
   작은 INSERT 심볼 중 하나로 추정. 에뮬레이터 줌인 후 원인 파악 필요.
- **HATCH 패턴**: Phase 8.6 + 후속 곡선경계 버그수정으로 일반 지원(작동 중 ✅). 남은 개선:
  타원호/스플라인 경계의 *패턴*(현재 솔리드 폴백), gradient fill(범위 외).

### 디버그/로깅
- `adb logcat | grep CleanCAD/` 로 ViewModel(파일 카피/파싱 타이밍, entity/layer 개수,
  extents bounds) + dwgjni(dwg_read_file rc, num_objects, serialized bytes) 추적 가능.
- 진단 워크플로우: `ref.dwg` 데이터 — `extents=BoundingBox(-2M..2M, -2.7M..1.5M)`,
  `mspace top-level=7,947`, `entities=100,000` (MAX_ENTITIES 도달), `serialized=6.2MB`, parse 1.2초.
- 디바이스 자동화 명령은 Phase 8.7 핸드오프 문서 참조 (`ADB shell input tap` 시퀀스).

### 이전 phase 요약
- **Phase 8.5**: DIMENSION block 전개 + `clone_ins_pt` 변환. 수치/화살표 정상 위치 렌더.
- **Phase 8**: LibreDWG 바이너리 API 직접 호출, native serializer, INSERT 재귀 전개.
- **Phase 7**: DXF 텍스트 중간단계 기반 시도. 인코딩/색상 부분만 해결, 누락 엔티티 미해결.
  Phase 8 채택 배경.
- **Phase 6**: 텍스트 이스케이프, 컬링, 릴리즈 서명, About.
- **Phase 5**: 다크모드, 설정, 최근파일.
- **Phase 0–4**: LibreDWG NDK 빌드 + DXF 파서 + Renderer 골격.

## Build & test
- After clone, init the submodule: `git submodule update --init --recursive`
- Build: `./gradlew :app:assembleDebug`
- Instrumented tests (need a running x86_64 emulator, e.g. AVD `Medium_Phone_API_36.1`):
  `./gradlew :app:connectedDebugAndroidTest`
- Toolchain: NDK `30.0.14904198`, CMake `4.1.2` (pinned in `app/build.gradle.kts`).

## Gotchas
- **Windows CRLF**: Git's system `core.autocrlf=true` checks out LibreDWG's
  `configure.ac` with CRLF, which corrupts the generated `config.h` and breaks the
  whole native compile. `app/src/main/cpp/CMakeLists.txt` strips CRs from
  `configure.ac` at configure time to work around this. (This leaves the submodule
  working tree dirty — that's expected; don't commit the submodule content change.)

## Conventions
- Immutable Kotlin data classes for the drawing model; many small, focused files.
- License: GPL v3 — linking LibreDWG makes the whole app GPL v3, so source stays public.
