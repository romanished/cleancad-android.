package io.github.june690602_blip.cleancad.render

import android.graphics.*
import io.github.june690602_blip.cleancad.model.*
import io.github.june690602_blip.cleancad.model.Drawing
import io.github.june690602_blip.cleancad.model.EntityColor
import kotlin.math.*

class EntityRenderer {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        // Phase 9.2: 2f → 1f. 대용량 도면 줌아웃 시 빽빽한 entity가 검은/흰 떡덩어리로
        // 뭉치는 것을 완화. anti-alias로 회색 trail 효과.
        strokeWidth = 1f
        color = Color.BLACK
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 14f
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }

    private var bgColor: Int = Color.WHITE
    private var defaultLineColor: Int = Color.BLACK
    private var layerColorMap: Map<String, Int> = emptyMap()
    private var entityColorByIdentity: Map<DxfEntity, Int> = emptyMap()
    private var isDarkBg: Boolean = false

    /** 현재 도면의 엔티티 (렌더 순서). drawAll 은 이 리스트 + [index] 로 동작. */
    private var entities: List<DxfEntity> = emptyList()

    /** 공간 인덱스 + worldBounds 캐시 (Phase 10). null 이면 전체 순회 폴백. */
    private var index: SpatialIndex? = null

    /** viewport 조회 결과 재사용 버퍼 (UI 스레드 전용). */
    private val visible = IntList()

    /** displayExtents 등 "이 박스 밖 엔티티는 영구 컬링" 용도. null이면 컬링 없음.
     *  화면 viewport와 별개 — 사용자가 줌아웃해도 outlier가 다시 보이지 않도록. */
    private var renderBounds: BoundingBox? = null

    /** LINE batch: 색상별로 primitive FloatArray로 [x1,y1,x2,y2, ...] 누적 후 한 번에 drawLines.
     *  ArrayList<Float>는 매 frame 수십만 Float autobox → GC 폭증 (Phase 9.2 1차 시도 후 Davey
     *  1~7초 잔존). primitive FloatArray로 autoboxing 제거. */
    private val lineBatch = HashMap<Int, FloatBuf>(64)

    /** 너무 작아 글자를 못 그리는 텍스트의 "여기 글자 있음" 힌트 막대(선) batch (Phase 11.5). */
    private val hintBatch = FloatBuf(1024)

    private class FloatBuf(initialCapacity: Int = 512) {
        var arr: FloatArray = FloatArray(initialCapacity); private set
        var size: Int = 0; private set
        fun add4(a: Float, b: Float, c: Float, d: Float) {
            if (size + 4 > arr.size) arr = arr.copyOf((arr.size * 2).coerceAtLeast(size + 4))
            arr[size]     = a
            arr[size + 1] = b
            arr[size + 2] = c
            arr[size + 3] = d
            size += 4
        }
        fun clear() { size = 0 }
        /** size 미만만 유효. drawLines 에는 trimmed copy 필요. */
        fun trimmedCopy(): FloatArray = arr.copyOf(size)
    }

    fun setColors(bgColor: Int, lineColor: Int) {
        this.bgColor = bgColor
        this.defaultLineColor = lineColor
        this.isDarkBg = ColorInvert.isDarkBackground(bgColor)
        linePaint.color = lineColor
        textPaint.color = lineColor
    }

    fun setRenderBounds(box: BoundingBox?) {
        renderBounds = box
    }

    fun setLayers(layers: List<Layer>) {
        layerColorMap = layers.associate { layer ->
            layer.name to AciColor.toArgb(layer.colorIndex, fallback = defaultLineColor)
        }
    }

    /** Phase 8: Drawing 전체를 받아 엔티티별 색상까지 lookup 가능하게 한다. */
    fun setDrawing(drawing: Drawing) {
        setLayers(drawing.layers)
        entities = drawing.entities
        // Phase 10: 로드 시 1회 공간 인덱스 구축 (renderBounds 와 동일한 region 사용).
        index = SpatialIndex.build(drawing.entities, drawing.displayExtents ?: drawing.extents)
        if (drawing.entityColors.isEmpty()) {
            entityColorByIdentity = emptyMap()
            return
        }
        val map = HashMap<DxfEntity, Int>(drawing.entities.size)
        for (i in drawing.entities.indices) {
            val ec = drawing.entityColors[i]
            val color: Int = when {
                ec.hasRgb -> 0xFF000000.toInt() or ec.rgb
                ec.isByLayer || ec.isByBlock ->
                    layerColorMap[drawing.entities[i].layer] ?: defaultLineColor
                else -> AciColor.toArgb(
                    ec.colorIndex,
                    fallback = layerColorMap[drawing.entities[i].layer] ?: defaultLineColor
                )
            }
            map[drawing.entities[i]] = color
        }
        entityColorByIdentity = map
    }

    private fun colorFor(entity: DxfEntity): Int {
        val raw = entityColorByIdentity[entity]
            ?: layerColorMap[entity.layer]
            ?: defaultLineColor
        return ColorInvert.maybeInvert(raw, isDarkBg)
    }

    /** Drawing의 모든 엔티티를 렌더 순서대로 Canvas에 그린다.
     *  컬링 전략:
     *   - renderBounds(displayExtents) 밖 엔티티 영구 스킵 (outlier 차단 — Phase 9.2)
     *   - viewport 밖 엔티티 스킵 (worldBounds vs viewport)
     *   - 화면상 너무 작아서 점만도 안 보이는 엔티티 스킵 (< 2px)
     *   - 텍스트는 base 글자 높이가 10px 미만이면 스킵 (zoom out 상태에서 까만 덩어리 방지)
     *  성능 전략 (Phase 9.2):
     *   - DxfLine 은 색상별 FloatArray 로 누적 후 canvas.drawLines() 한 번으로 flush.
     *     drawPath 호출 수십만 회 → drawLines 호출 수십 회 (색상 종류 수).
     *     GPU 명령 큐 ~100배 감소 → 메인 스레드 ANR 해결. */
    fun drawAll(
        canvas: Canvas,
        matrix: Matrix,
        viewport: BoundingBox? = null
    ) {
        val ents = entities
        if (ents.isEmpty()) return
        val scale = CoordTransform.currentScale(matrix)
        val rb = renderBounds
        lineBatch.values.forEach { it.clear() }

        // Phase 10: 공간 인덱스로 viewport 와 겹치는 후보만 추린다 (188K → 가시 영역 수천).
        // 인덱스/viewport 없으면 전체 순회 폴백.
        val idx = index
        val cBounds = idx?.bounds
        val candidates = visible
        if (idx != null && viewport != null) {
            idx.query(viewport, candidates)
        } else {
            candidates.clear()
            for (i in ents.indices) candidates.add(i)
        }
        val data = candidates.data
        val cnt = candidates.size

        // pass 1: 비텍스트 — LINE 은 색상별 FloatArray 배칭, 나머지는 즉시 draw.
        for (k in 0 until cnt) {
            val i = data[k]
            val entity = ents[i]
            if (entity is DxfText || entity is DxfMText) continue
            val bounds = cBounds?.get(i) ?: SpatialIndex.boundsFor(entity)
            if (bounds != null) {
                if (rb != null && !bounds.intersects(rb)) continue
                if (viewport != null && !bounds.intersects(viewport)) continue
                // Phase 9.2: pixel cull. 가로+세로 합이 3px 미만이면 스킵.
                // 단 POINT 는 크기 0이라 픽셀컬에 걸리므로 예외 — 고정 화면 점으로 항상 렌더.
                if (entity !is DxfPoint) {
                    val pixW = bounds.width * scale
                    val pixH = bounds.height * scale
                    if (pixW + pixH < 3.0) continue
                }
            }
            if (entity is DxfLine) {
                val s = CoordTransform.worldToScreen(entity.start, matrix)
                val e = CoordTransform.worldToScreen(entity.end, matrix)
                val color = colorFor(entity)
                val buf = lineBatch.getOrPut(color) { FloatBuf(1024) }
                buf.add4(s.x, s.y, e.x, e.y)
            } else {
                draw(entity, canvas, matrix)
            }
        }
        // flush LINE batch — 색상마다 한 번씩 drawLines.
        for ((color, buf) in lineBatch) {
            if (buf.size == 0) continue
            linePaint.color = color
            canvas.drawLines(buf.trimmedCopy(), linePaint)
        }

        // pass 2: 텍스트 — 지오메트리 위에 얹는다. 후보는 이미 viewport 로 컬링됨.
        // 글자높이 >=10px: 실제 글자. 3~10px: 힌트 막대(ZWCAD처럼 "여기 글자 있음" 표시). <3px: 스킵.
        hintBatch.clear()
        for (k in 0 until cnt) {
            when (val entity = ents[data[k]]) {
                is DxfText -> {
                    val px = entity.height * scale
                    if (px >= MIN_TEXT_BASE_PIXELS) draw(entity, canvas, matrix)
                    else if (px >= TEXT_HINT_MIN_PIXELS)
                        addTextHint(entity.insertionPoint, entity.text, px, entity.rotationDeg, matrix)
                }
                is DxfMText -> {
                    val px = entity.height * scale
                    if (px >= MIN_TEXT_BASE_PIXELS) draw(entity, canvas, matrix)
                    else if (px >= TEXT_HINT_MIN_PIXELS)
                        addTextHint(entity.insertionPoint, entity.text, px, entity.rotationDeg, matrix)
                }
                else -> { /* already drawn in first pass */ }
            }
        }
        if (hintBatch.size > 0) {
            linePaint.color = (defaultLineColor and 0x00FFFFFF) or (0x55 shl 24)  // ~33% 알파 힌트
            canvas.drawLines(hintBatch.trimmedCopy(), linePaint)
            linePaint.color = defaultLineColor
        }
    }

    /** 글자가 너무 작아 못 그릴 때 "여기 글자 있음" 힌트 선분 1개를 batch 에 추가한다.
     *  글자폭 ≈ 글자수×높이×0.55, 텍스트 진행방향으로 배치(회전 반영), 한 번에 drawLines. */
    private fun addTextHint(insertion: Vec2, text: String, pxHeight: Double, rotDeg: Double, matrix: Matrix) {
        val pt = CoordTransform.worldToScreen(insertion, matrix)
        val n = text.length.coerceIn(1, 40)
        val wPx = (n * pxHeight * 0.55).toFloat()
        val r = Math.toRadians(rotDeg)
        val dx = Math.cos(r).toFloat()
        val dy = (-Math.sin(r)).toFloat()
        val yoff = (pxHeight * 0.35).toFloat()      // 베이스라인보다 위(중앙 근사). 진행방향 수직=(dy,-dx)
        val ox = pt.x + dy * yoff
        val oy = pt.y - dx * yoff
        hintBatch.add4(ox, oy, ox + wPx * dx, oy + wPx * dy)
    }

    private companion object {
        /** zoom out 상태에서 글자 자체가 이 픽셀 수보다 작아지면 렌더 자체를 스킵.
         *  까만 글자 덩어리(수많은 작은 텍스트 mass) 방지. Phase 9.1: 4→10 (대용량 도면 ANR 방지). */
        const val MIN_TEXT_BASE_PIXELS: Double = 10.0

        /** 글자높이가 이 px 이상~MIN_TEXT_BASE_PIXELS 미만이면 힌트 막대로 표시(Phase 11.5).
         *  이 값 미만은 너무 작아 노이즈 → 스킵. */
        const val TEXT_HINT_MIN_PIXELS: Double = 3.0

        /** HATCH 솔리드 채우기 알파 — 0x40 = 25% 불투명도 (반투명).
         *  패턴 hatch가 미지원이라 검정 솔리드 덩어리 방지 목적. */
        const val HATCH_FILL_ALPHA_MASK: Int = 0x40000000

        /** 패턴 채움 라인 최소 화면 간격(px). 이 미만이면 라인 대신 반투명 솔리드(조밀 폴백). */
        const val HATCH_MIN_PATTERN_SPACING_PX: Double = 3.0

        /** POINT 점 마커 반경 (화면 px, 줌 무관 고정). */
        const val POINT_RADIUS_PX: Float = 1.5f
    }

    private fun draw(entity: DxfEntity, canvas: Canvas, matrix: Matrix) {
        linePaint.color = colorFor(entity)
        textPaint.color = colorFor(entity)
        when (entity) {
            is DxfLine       -> drawLine(entity, canvas, matrix)
            is DxfPoint      -> drawPoint(entity, canvas, matrix)
            is DxfCircle     -> drawCircle(entity, canvas, matrix)
            is DxfArc        -> drawArc(entity, canvas, matrix)
            is DxfLwPolyline -> drawLwPolyline(entity, canvas, matrix)
            is DxfPolyline   -> drawPolyline(entity, canvas, matrix)
            is Dxf3DFace     -> draw3dFace(entity, canvas, matrix)
            is DxfSolid      -> drawSolid(entity, canvas, matrix)
            is DxfEllipse    -> drawEllipse(entity, canvas, matrix)
            is DxfSpline     -> drawSpline(entity, canvas, matrix)
            is DxfText       -> drawText(entity, canvas, matrix)
            is DxfMText      -> drawMText(entity, canvas, matrix)
            is DxfDimension  -> drawDimension(entity, canvas, matrix)
            is DxfLeader     -> drawLeader(entity, canvas, matrix)
            is DxfHatch      -> drawHatch(entity, canvas, matrix)
            is DxfInsert, is DxfUnknown -> { /* skip */ }
        }
    }

    private fun drawLine(e: DxfLine, canvas: Canvas, matrix: Matrix) {
        val s = CoordTransform.worldToScreen(e.start, matrix)
        val end = CoordTransform.worldToScreen(e.end, matrix)
        canvas.drawLine(s.x, s.y, end.x, end.y, linePaint)
    }

    /** POINT: 줌 무관 고정 화면 크기의 작은 점으로 렌더 (CAD PDMODE=0 기본 동작 근사). */
    private fun drawPoint(e: DxfPoint, canvas: Canvas, matrix: Matrix) {
        val p = CoordTransform.worldToScreen(e.position, matrix)
        fillPaint.color = colorFor(e)
        canvas.drawCircle(p.x, p.y, POINT_RADIUS_PX, fillPaint)
    }

    private fun drawCircle(e: DxfCircle, canvas: Canvas, matrix: Matrix) {
        val c = CoordTransform.worldToScreen(e.center, matrix)
        val r = (e.radius * CoordTransform.currentScale(matrix)).toFloat()
        canvas.drawCircle(c.x, c.y, r, linePaint)
    }

    private fun drawArc(e: DxfArc, canvas: Canvas, matrix: Matrix) {
        val c = CoordTransform.worldToScreen(e.center, matrix)
        val r = (e.radius * CoordTransform.currentScale(matrix)).toFloat()
        val oval = RectF(c.x - r, c.y - r, c.x + r, c.y + r)
        var sweep = (e.endAngleDeg - e.startAngleDeg).toFloat()
        if (sweep <= 0f) sweep += 360f
        val startAngle = (-e.endAngleDeg).toFloat()
        canvas.drawArc(oval, startAngle, sweep, false, linePaint)
    }

    private fun drawLwPolyline(e: DxfLwPolyline, canvas: Canvas, matrix: Matrix) {
        if (e.vertices.size < 2) return
        val path = Path()
        val first = CoordTransform.worldToScreen(e.vertices[0], matrix)
        path.moveTo(first.x, first.y)
        for (i in 1 until e.vertices.size) {
            val pt = CoordTransform.worldToScreen(e.vertices[i], matrix)
            path.lineTo(pt.x, pt.y)
        }
        if (e.closed) path.close()
        canvas.drawPath(path, linePaint)
    }

    private fun drawPolyline(e: DxfPolyline, canvas: Canvas, matrix: Matrix) {
        if (e.vertices.size < 2) return
        val path = Path()
        val first = CoordTransform.worldToScreen(e.vertices[0], matrix)
        path.moveTo(first.x, first.y)
        for (i in 1 until e.vertices.size) {
            val pt = CoordTransform.worldToScreen(e.vertices[i], matrix)
            path.lineTo(pt.x, pt.y)
        }
        if (e.closed) path.close()
        canvas.drawPath(path, linePaint)
    }

    private fun draw3dFace(e: Dxf3DFace, canvas: Canvas, matrix: Matrix) {
        val p1 = CoordTransform.worldToScreen(e.corner1, matrix)
        val p2 = CoordTransform.worldToScreen(e.corner2, matrix)
        val p3 = CoordTransform.worldToScreen(e.corner3, matrix)
        val p4 = CoordTransform.worldToScreen(e.corner4, matrix)
        val path = Path()
        path.moveTo(p1.x, p1.y)
        path.lineTo(p2.x, p2.y)
        path.lineTo(p3.x, p3.y)
        if (e.corner4 != e.corner3) path.lineTo(p4.x, p4.y)
        path.close()
        canvas.drawPath(path, linePaint)
    }

    private fun drawSolid(e: DxfSolid, canvas: Canvas, matrix: Matrix) {
        // SOLID vertex order: 1-2-4-3 (legacy)
        val p1 = CoordTransform.worldToScreen(e.corner1, matrix)
        val p2 = CoordTransform.worldToScreen(e.corner2, matrix)
        val p3 = CoordTransform.worldToScreen(e.corner3, matrix)
        val p4 = CoordTransform.worldToScreen(e.corner4, matrix)
        val path = Path()
        path.moveTo(p1.x, p1.y)
        path.lineTo(p2.x, p2.y)
        path.lineTo(p4.x, p4.y)   // 4 first (legacy order)
        if (e.corner3 != e.corner4) path.lineTo(p3.x, p3.y)
        path.close()
        fillPaint.color = linePaint.color
        canvas.drawPath(path, fillPaint)
    }

    private fun drawHatch(e: DxfHatch, canvas: Canvas, matrix: Matrix) {
        if (e.paths.isEmpty()) return
        val path = Path()
        for (boundary in e.paths) {
            if (boundary.size < 2) continue
            val first = CoordTransform.worldToScreen(boundary[0], matrix)
            path.moveTo(first.x, first.y)
            for (i in 1 until boundary.size) {
                val pt = CoordTransform.worldToScreen(boundary[i], matrix)
                path.lineTo(pt.x, pt.y)
            }
            path.close()
        }
        val screenSpacing = e.minLineSpacing * CoordTransform.currentScale(matrix)
        val showPattern = !e.isSolid && !e.patternFallback &&
            e.fillLines.isNotEmpty() && screenSpacing >= HATCH_MIN_PATTERN_SPACING_PX
        when {
            showPattern -> drawHatchFillLines(e, canvas, matrix)
            e.isSolid || e.patternFallback || e.fillLines.isNotEmpty() -> {
                // 솔리드 hatch, 폴백, 또는 이 줌에선 패턴이 너무 조밀 → 반투명 솔리드
                fillPaint.color = (linePaint.color and 0x00FFFFFF) or HATCH_FILL_ALPHA_MASK
                canvas.drawPath(path, fillPaint)
            }
            // else: 비솔리드 + 패턴 정보 없음 → 채움 없이 경계만
        }
        // 경계는 항상 그림 (솔리드든 패턴이든 boundary 시각화)
        canvas.drawPath(path, linePaint)
    }

    /** 패턴 채움 라인(월드 세그먼트)을 스크린으로 변환해 한 번에 drawLines. */
    private fun drawHatchFillLines(e: DxfHatch, canvas: Canvas, matrix: Matrix) {
        val pts = e.fillLines
        val arr = FloatArray(pts.size * 2)
        var j = 0
        for (p in pts) {
            val s = CoordTransform.worldToScreen(p, matrix)
            arr[j++] = s.x; arr[j++] = s.y
        }
        canvas.drawLines(arr, linePaint)
    }

    private fun drawEllipse(e: DxfEllipse, canvas: Canvas, matrix: Matrix) {
        val majorLen = sqrt(e.majorAxis.x * e.majorAxis.x + e.majorAxis.y * e.majorAxis.y)
        val minorLen = majorLen * e.minorRatio
        val rot = atan2(e.majorAxis.y, e.majorAxis.x)
        val steps = 72
        val path = Path()
        val paramRange = e.endParam - e.startParam
        for (i in 0..steps) {
            val t = e.startParam + i.toDouble() / steps * paramRange
            val wx = e.center.x + majorLen * cos(t) * cos(rot) - minorLen * sin(t) * sin(rot)
            val wy = e.center.y + majorLen * cos(t) * sin(rot) + minorLen * sin(t) * cos(rot)
            val pt = CoordTransform.worldToScreen(wx, wy, matrix)
            if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
        }
        canvas.drawPath(path, linePaint)
    }

    private fun drawSpline(e: DxfSpline, canvas: Canvas, matrix: Matrix) {
        if (e.controlPoints.size < 2) return
        val path = Path()
        val first = CoordTransform.worldToScreen(e.controlPoints[0], matrix)
        path.moveTo(first.x, first.y)
        for (i in 1 until e.controlPoints.size) {
            val pt = CoordTransform.worldToScreen(e.controlPoints[i], matrix)
            path.lineTo(pt.x, pt.y)
        }
        canvas.drawPath(path, linePaint)
    }

    private fun drawText(e: DxfText, canvas: Canvas, matrix: Matrix) {
        val pt = CoordTransform.worldToScreen(e.insertionPoint, matrix)
        textPaint.textSize = (e.height * CoordTransform.currentScale(matrix)).toFloat()
            .coerceAtLeast(8f)
        textPaint.textAlign = hAlignOf(e.hAlign)
        val dy = vOffsetOf(e.vAlign)
        canvas.save()
        canvas.translate(pt.x, pt.y)
        canvas.rotate(-e.rotationDeg.toFloat())
        canvas.drawText(e.text, 0f, dy, textPaint)
        canvas.restore()
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawMText(e: DxfMText, canvas: Canvas, matrix: Matrix) {
        val pt = CoordTransform.worldToScreen(e.insertionPoint, matrix)
        textPaint.textSize = (e.height * CoordTransform.currentScale(matrix)).toFloat()
            .coerceAtLeast(8f)
        val stripped = e.text
            .replace(Regex("\\\\[A-Za-z][^;]*;"), "")
            .replace(Regex("\\\\[^A-Za-z]"), "")
            .replace(Regex("[{}]"), "")
            .replace("\\P", "\n")
        textPaint.textAlign = hAlignOf(e.hAlign)
        val dy = vOffsetOf(e.vAlign)
        canvas.save()
        canvas.translate(pt.x, pt.y)
        canvas.rotate(-e.rotationDeg.toFloat())
        canvas.drawText(stripped, 0f, dy, textPaint)
        canvas.restore()
        textPaint.textAlign = Paint.Align.LEFT
    }

    /** hAlign(0 left,1 center,2 right) → Paint.Align. */
    private fun hAlignOf(h: Int): Paint.Align = when (h) {
        1 -> Paint.Align.CENTER
        2 -> Paint.Align.RIGHT
        else -> Paint.Align.LEFT
    }

    /** vAlign(0 baseline,1 bottom,2 middle,3 top) → drawText baseline 오프셋(dy). */
    private fun vOffsetOf(v: Int): Float {
        if (v == 0) return 0f
        val fm = textPaint.fontMetrics
        return when (v) {
            1 -> -fm.descent                    // bottom
            2 -> -(fm.ascent + fm.descent) / 2f // middle
            3 -> -fm.ascent                     // top
            else -> 0f
        }
    }

    private fun drawDimension(e: DxfDimension, canvas: Canvas, matrix: Matrix) {
        val dp = CoordTransform.worldToScreen(e.definitionPoint, matrix)
        val tp = CoordTransform.worldToScreen(e.textMidPoint, matrix)
        canvas.drawLine(dp.x, dp.y, tp.x, tp.y, linePaint)
        if (e.textOverride.isNotBlank()) {
            textPaint.textSize = (2.5 * CoordTransform.currentScale(matrix)).toFloat().coerceAtLeast(8f)
            canvas.drawText(e.textOverride, tp.x, tp.y, textPaint)
        }
    }

    private fun drawLeader(e: DxfLeader, canvas: Canvas, matrix: Matrix) {
        if (e.vertices.size < 2) return
        val path = Path()
        val first = CoordTransform.worldToScreen(e.vertices[0], matrix)
        path.moveTo(first.x, first.y)
        for (i in 1 until e.vertices.size) {
            val pt = CoordTransform.worldToScreen(e.vertices[i], matrix)
            path.lineTo(pt.x, pt.y)
        }
        canvas.drawPath(path, linePaint)
    }
}
